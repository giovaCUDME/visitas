from flask import Flask, session, redirect, url_for
from flask import request
from flask import render_template_string

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Cambia esto por una clave segura en producción

@app.route('/')
def index():
	visitas = session.get('visitas', 0)
	reinicios = session.get('reinicios', 0)
	visitas += 1
	session['visitas'] = visitas
	html = '''
	<h1>Has visitado este sitio {{ visitas }} veces.</h1>
	<h2>El contador ha sido reiniciado {{ reinicios }} veces.</h2>
	<form method="post" action="/aumentar">
		<button type="submit">Aumentar +2</button>
	</form>
	<form method="post" action="/aumentar_personalizado">
		<input type="number" name="cantidad" min="1" required>
		<button type="submit">Aumentar por cantidad</button>
	</form>
	<form method="post" action="/reiniciar">
		<button type="submit">Reiniciar contador</button>
	</form>
	'''
	return render_template_string(html, visitas=visitas, reinicios=reinicios)

@app.route('/aumentar', methods=['POST'])
def aumentar():
	visitas = session.get('visitas', 0)
	visitas += 2
	session['visitas'] = visitas
	return redirect(url_for('index'))

@app.route('/reiniciar', methods=['POST'])
def reiniciar():
	session['visitas'] = 0
	reinicios = session.get('reinicios', 0)
	session['reinicios'] = reinicios + 1
	return redirect(url_for('index'))

@app.route('/aumentar_personalizado', methods=['POST'])
def aumentar_personalizado():
	try:
		cantidad = int(request.form.get('cantidad', 1))
	except ValueError:
		cantidad = 1
	visitas = session.get('visitas', 0)
	visitas += cantidad
	session['visitas'] = visitas
	return redirect(url_for('index'))

if __name__ == '__main__':
	app.run(debug=True)
