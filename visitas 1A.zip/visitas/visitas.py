from flask import Flask


def create_app(test_config=None):
    """Application factory for the visitas app."""
    app = Flask(__name__, template_folder='templates')
    app.config.from_mapping(
        SECRET_KEY='supersecretkey',  # Replace in production
    )

    # Register views (views.py must be in the same folder)
    import views
    views.register_views(app)

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
