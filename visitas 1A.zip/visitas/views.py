from flask import render_template, session, redirect, url_for, request, Blueprint

bp = Blueprint('visitas', __name__)


def register_views(app):
    app.register_blueprint(bp)


@bp.route('/')
def index():
    visitas = session.get('visitas', 0)
    reinicios = session.get('reinicios', 0)
    visitas += 1
    session['visitas'] = visitas
    return render_template('index.html', visitas=visitas, reinicios=reinicios)


@bp.route('/aumentar', methods=['POST'])
def aumentar():
    visitas = session.get('visitas', 0)
    visitas += 2
    session['visitas'] = visitas
    return redirect(url_for('visitas.index'))


@bp.route('/reiniciar', methods=['POST'])
def reiniciar():
    session['visitas'] = 0
    reinicios = session.get('reinicios', 0)
    session['reinicios'] = reinicios + 1
    return redirect(url_for('visitas.index'))


@bp.route('/aumentar_personalizado', methods=['POST'])
def aumentar_personalizado():
    try:
        cantidad = int(request.form.get('cantidad', 1))
    except (ValueError, TypeError):
        cantidad = 1
    visitas = session.get('visitas', 0)
    visitas += cantidad
    session['visitas'] = visitas
    return redirect(url_for('visitas.index'))


@bp.route('/destruir_sesion')
def destruir_sesion():
    session.clear()
    return redirect(url_for('visitas.index'))
